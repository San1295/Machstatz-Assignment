//pressure
function showpressurechart()
{
		$.getJSON('https://gitlab.com/snippets/1872662/raw', function(data){
				generateGraph('chartp',data.pressure_machine_1,data.pressure_machine_2);
		});
}
	
	showpressurechart();
	
//temperature
function showtempchart()
{
		$.getJSON('https://gitlab.com/snippets/1872645/raw', function(data){
				generateGraph('chartt',data.temp_machine_1,data.temp_machine_2);
		});
}
	
	showtempchart();	

//graph generation
function generateGraph(id,data1,data2){
	
if(id=="chartp"){
	var tempobj = {
    bindto: '#'+id,
    data: {
      columns: [['pressure_machine_1'],['pressure_machine_2']]
    }
}
	
}else{
	var tempobj = {
    bindto: '#'+id,
    data: {
      columns: [['temp_machine_1'],['temp_machine_2']]
    }
}	
	
}
	for(var i=0; i<data1.length; i++){
		
		tempobj.data.columns[0].push(data1[i]);
	}
	for(var i=0; i<data2.length; i++){
		tempobj.data.columns[1].push(data2[i]);
	}
	
	console.log(tempobj);


var chart = c3.generate(tempobj);
}