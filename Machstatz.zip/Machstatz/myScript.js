//signup form validation
function signupvalidate(){
	
	//validate first name
	var status = true;
	var fname = document.getElementById("fname").value.trim();
	if(fname=="")
	{
		status = false;
		document.getElementById("fname").style.borderColor="red";
	}
	else
	{
		document.getElementById("fname").style.borderColor="green";
	}
	
	//validate last name
	var lname = document.getElementById("lname").value.trim();
	if(lname=="")
	{
		status = false;
		document.getElementById("lname").style.borderColor="red";
	}
	else
	{
		document.getElementById("lname").style.borderColor="green";
	}
	
	//validate email
	var status = true;
	var email = document.getElementById("email").value.trim();
	if(email=="")
	{
		status = false;
		document.getElementById("email").style.borderColor="red";
	}
	else
	{
		document.getElementById("email").style.borderColor="green";
	}
	
	//validate mobile number
	var status = true;
	var mobile = document.getElementById("mobile").value.trim();
	if(mobile=="")
	{
		status = false;
		document.getElementById("mobile").style.borderColor="red";
	}
	else
	{
		document.getElementById("mobile").style.borderColor="green";
	}
	
	//validate username
	var status = true;
	var uname = document.getElementById("uname").value.trim();
	if(uname=="")
	{
		status = false;
		document.getElementById("uname").style.borderColor="red";
	}
	else
	{
		document.getElementById("uname").style.borderColor="green";
	}
	
	//validate password
	var status = true;
	var pass = document.getElementById("pass").value.trim();
	if(pass=="")
	{
		status = false;
		document.getElementById("pass").style.borderColor="red";
	}
	else
	{
		document.getElementById("pass").style.borderColor="green";
	}
	
		return status;
}
 
 //new user
 function saveuser()
{
	var login = false;
	var uname = document.getElementById("uname").value;
	var pass = document.getElementById("pass").value;
	var alluser = JSON.parse(localStorage.getItem("user"));

		for(var i = 0; i<alluser.length; i++) //for all user
		{
			if((uname == alluser[i].uname) && (pass==alluser[i].pass))
			{
				login = true;
			}
		}
		if(login == true)
		{ 
			localStorage.setItem("name",uname); // login data
			localStorage.setItem("pass",pass); // login data
			window.location.href = "login.html";
		}

}
 //login form validation
function validate()
{
	var username=document.getElementById("uname").value.trim();
	var passwd=document.getElementById("pass").value.trim();
	
	if((username=="admin") && (passwd=="admin")) //authentication condition
	{
		location.href ="home.html"; //direct to home page
	}
	else
	{
		alert("invalid");
	}
	var username=document.getElementById("uname").value=""; //to clear input field
}

//display pressure
function showpressure()
{
		$.getJSON('https://gitlab.com/snippets/1872663/raw', function(data){
				var item = JSON.parse(data); //conversion from JSON to Array
				console.log(item);
				var data= "<p>" + item + "</p>";
				document.getElementById("msgp").innerHTML=data;
		});
}
	
	showpressure();

//display temperature			
function showtemperature()
{
		$.getJSON('https://gitlab.com/snippets/1872664/raw', function(data){
				var item = JSON.parse(data); //conversion from JSON to Array	
				console.log(item);
				var data= "<p>" + item + "</p>";
				document.getElementById("msgt").innerHTML=data;
		});
}
			
	showtemperature();

//logout
function logout(){
		 window.location.href = "login.html";
}

